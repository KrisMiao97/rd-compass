# 研发罗盘 0.4.0 · WorkBuddy 更新包

中文 / English

在 WorkBuddy 技能页选择“添加技能 → 上传技能”，选择本 ZIP。根目录 SKILL.md 的 name 保持 rd-compass，版本为 0.4.0。若客户端提示同名技能，请按界面提示处理；本包不自动改动已有研究数据或全局模型设置。

本次新增三种研究模式、现有路线与候选方向分离、事件类型、多点引用和阅读清单同步。默认报告解释技术及条件判断；只有任务需要时展开验证计划。

打开 demo/index.html 可直接查看合成示例，所有材料均虚构。生成新报告需要 Python 3.10+；真实检索需要宿主已授权来源。核心脚本与 GitHub 同版源一致，SKILL.md 增加双语发现字段和此宿主入口。

Upload this ZIP using Add skill → Upload skill. The root SKILL.md keeps the stable name rd-compass and version 0.4.0. Follow the client prompt if an existing skill has the same name. Open demo/index.html for a fictional offline preview. Generating reports requires Python 3.10+; real research requires authorized sources. Core research instructions are primarily Chinese.

[官方上传说明 / Official upload guide](https://www.workbuddy.cn/docs/workbuddy/From-Beginner-to-Expert-Guide/Function-Description/Skills-Market)
[源代码 / Source](https://github.com/KrisMiao97/rd-compass)

本包已做解压、核心文件比对及渲染检查；不宣称已在 WorkBuddy 客户端完成导入。
